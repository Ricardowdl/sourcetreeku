var name='小明'
var age=18
var flag=true

function sun(num1,num2){
    return num1+num2;

}

if(flag){
    console.log(sum(20,30))
}

export{
    flag:flag,
    sum:sum
}