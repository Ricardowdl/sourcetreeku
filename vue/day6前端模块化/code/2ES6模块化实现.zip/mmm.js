import {flag} from "./aaa"


if(flag){
    console.log('小明是天才')
}